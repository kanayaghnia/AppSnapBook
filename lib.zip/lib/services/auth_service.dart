class AuthService {
  static bool isLoggedIn = false;

  static String savedUsername = '';
  static String savedEmail = '';
  static String savedPassword = '';
  static String savedPhone = '';

  // Data user yang sedang login
  static String currentUsername = '';
  static String currentEmail = '';
  static String currentPhone = '';
  static String? currentPhotoPath;

  static String message = '';

  // ── REGISTER ─────────────────────────────────────────────────
  static bool register({
    required String username,
    required String email,
    required String password,
  }) {
    final emailValid =
    RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email);
    final passwordValid =
    RegExp(r'^(?=.*[A-Z])(?=.*[0-9]).{6,}$').hasMatch(password);

    if (username.isEmpty) {
      message = 'Username wajib diisi';
      return false;
    }
    if (email.isEmpty || password.isEmpty) {
      message = 'Email dan Password wajib diisi';
      return false;
    }
    if (!emailValid) {
      message = 'Format email tidak valid';
      return false;
    }
    if (!passwordValid) {
      message = 'Password wajib ada huruf besar dan angka';
      return false;
    }

    savedUsername = username;
    savedEmail = email;
    savedPassword = password;
    savedPhone = '';
    message = 'Register berhasil';
    return true;
  }

  // ── LOGIN ─────────────────────────────────────────────────────
  static bool login({
    required String email,
    required String password,
  }) {
    if (email.isEmpty || password.isEmpty) {
      message = 'Email dan Password wajib diisi';
      return false;
    }
    if (email != savedEmail || password != savedPassword) {
      message = 'Email atau Password salah';
      return false;
    }

    isLoggedIn = true;
    currentUsername = savedUsername;
    currentEmail = savedEmail;
    currentPhone = savedPhone;
    message = 'Login berhasil';
    return true;
  }

  // ── UPDATE PROFILE ────────────────────────────────────────────
  static bool updateProfile({
    required String username,
    required String email,
    required String phone,
    String? photoPath,
  }) {
    if (username.isEmpty) {
      message = 'Username wajib diisi';
      return false;
    }
    if (email.isEmpty) {
      message = 'Email wajib diisi';
      return false;
    }
    if (!RegExp(r'^[^@]+@[^@]+\.[^@]+').hasMatch(email)) {
      message = 'Format email tidak valid';
      return false;
    }

    currentUsername = username;
    currentEmail = email;
    currentPhone = phone;
    savedUsername = username;
    savedEmail = email;
    savedPhone = phone;
    if (photoPath != null) currentPhotoPath = photoPath;
    message = 'Profil berhasil diperbarui';
    return true;
  }

  // ── LOGOUT ────────────────────────────────────────────────────
  static void logout() {
    isLoggedIn = false;
    currentUsername = '';
    currentEmail = '';
    currentPhone = '';
    currentPhotoPath = null;
  }
}