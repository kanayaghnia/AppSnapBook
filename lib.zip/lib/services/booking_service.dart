import '../models/booking_model.dart';

class BookingService {
  static List<BookingModel> bookings = [];

  static void addBooking(BookingModel booking) {
    bookings.add(booking);
  }

  static void payBooking(int index) {
    bookings[index] = bookings[index].copyWith(status: 'Lunas');
  }

  static void rateBooking(int index, int rating) {
    bookings[index] = bookings[index].copyWith(rating: rating);
  }
}