// lib/services/favorite_service.dart
//
// Static service untuk menyimpan studio favorit selama sesi app berjalan.
// Cara kerja sama seperti BookingService — tidak perlu database dulu.

class FavoriteService {
  FavoriteService._();

  // Set of studio name yang sudah difavoritkan
  static final Set<String> _favorites = {};

  static bool isFavorite(String studioName) =>
      _favorites.contains(studioName);

  static void toggle(String studioName) {
    if (_favorites.contains(studioName)) {
      _favorites.remove(studioName);
    } else {
      _favorites.add(studioName);
    }
  }

  static List<String> get favoriteNames => _favorites.toList();
}