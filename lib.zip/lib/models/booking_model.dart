class BookingModel {
  final String studio;
  final String category;
  final String date;
  final String time;
  final String people;
  final String payment;
  final int price;
  final String status;
  final int? rating; // null = belum dirating

  BookingModel({
    required this.studio,
    required this.category,
    required this.date,
    required this.time,
    required this.people,
    required this.payment,
    required this.price,
    required this.status,
    this.rating,
  });

  BookingModel copyWith({
    String? studio,
    String? category,
    String? date,
    String? time,
    String? people,
    String? payment,
    int? price,
    String? status,
    int? rating,
  }) {
    return BookingModel(
      studio:   studio   ?? this.studio,
      category: category ?? this.category,
      date:     date     ?? this.date,
      time:     time     ?? this.time,
      people:   people   ?? this.people,
      payment:  payment  ?? this.payment,
      price:    price    ?? this.price,
      status:   status   ?? this.status,
      rating:   rating   ?? this.rating,
    );
  }
}