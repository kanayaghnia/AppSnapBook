import 'package:flutter/material.dart';
import 'package:snapbook/theme/colors.dart';
import 'package:snapbook/screens/booking/booking_screen.dart';

class ScheduleScreen extends StatefulWidget {
  const ScheduleScreen({super.key});

  @override
  State<ScheduleScreen> createState() => _ScheduleScreenState();
}

class _ScheduleScreenState extends State<ScheduleScreen> {
  DateTime _focusedMonth = DateTime.now();
  DateTime? _selectedDay;

  final List<Map<String, dynamic>> _bookings = [
    {
      'date': DateTime(2026, 5, 28),
      'studio': 'Studio A – Minimalist',
      'time': '10.00 – 12.00 WIB',
      'package': 'Personal Photoshoot',
      'status': 'Akan Datang',
      'seed': 'sched_studio_1',
    },
    {
      'date': DateTime(2026, 6, 5),
      'studio': 'Studio B – Vintage',
      'time': '13.00 – 15.00 WIB',
      'package': 'Graduation Package',
      'status': 'Akan Datang',
      'seed': 'sched_studio_2',
    },
    {
      'date': DateTime(2026, 6, 15),
      'studio': 'Studio C – Modern',
      'time': '09.00 – 11.00 WIB',
      'package': 'Prewedding Package',
      'status': 'Akan Datang',
      'seed': 'sched_studio_3',
    },
  ];

  List<DateTime> get _bookedDates =>
      _bookings.map((b) => b['date'] as DateTime).toList();

  List<Map<String, dynamic>> _bookingsForDay(DateTime day) => _bookings
      .where((b) => _isSameDay(b['date'] as DateTime, day))
      .toList();

  bool _isSameDay(DateTime a, DateTime b) =>
      a.year == b.year && a.month == b.month && a.day == b.day;

  bool _isBooked(DateTime day) =>
      _bookedDates.any((d) => _isSameDay(d, day));

  void _prevMonth() => setState(() {
    _focusedMonth =
        DateTime(_focusedMonth.year, _focusedMonth.month - 1);
  });

  void _nextMonth() => setState(() {
    _focusedMonth =
        DateTime(_focusedMonth.year, _focusedMonth.month + 1);
  });

  @override
  Widget build(BuildContext context) {
    final selectedBookings = _selectedDay != null
        ? _bookingsForDay(_selectedDay!)
        : _bookings;

    return Scaffold(
      backgroundColor: AppColors.background,
      appBar: AppBar(
        title: const Text('Jadwal Saya',
            style: TextStyle(
                color: AppColors.black,
                fontWeight: FontWeight.bold,
                fontSize: 18)),
        centerTitle: true,
        backgroundColor: AppColors.background,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        iconTheme: const IconThemeData(color: AppColors.black),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(1),
          child: Container(color: AppColors.lightGrey, height: 1),
        ),
      ),
      body: Column(
        children: [
          // ── Calendar ─────────────────────────────────────────
          Container(
            margin: const EdgeInsets.fromLTRB(20, 16, 20, 0),
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppColors.white,
              borderRadius: BorderRadius.circular(18),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.05),
                  blurRadius: 12,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Column(
              children: [
                // Month nav
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    GestureDetector(
                      onTap: _prevMonth,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.chevron_left,
                            color: AppColors.black, size: 20),
                      ),
                    ),
                    Text(
                      _monthLabel(_focusedMonth),
                      style: const TextStyle(
                          fontSize: 15,
                          fontWeight: FontWeight.w700,
                          color: AppColors.black),
                    ),
                    GestureDetector(
                      onTap: _nextMonth,
                      child: Container(
                        padding: const EdgeInsets.all(6),
                        decoration: BoxDecoration(
                          color: AppColors.background,
                          borderRadius: BorderRadius.circular(8),
                        ),
                        child: const Icon(Icons.chevron_right,
                            color: AppColors.black, size: 20),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                // Day labels
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: ['Min', 'Sen', 'Sel', 'Rab', 'Kam', 'Jum', 'Sab']
                      .map((d) => SizedBox(
                    width: 32,
                    child: Text(d,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: AppColors.grey)),
                  ))
                      .toList(),
                ),
                const SizedBox(height: 8),
                // Days grid
                _buildDaysGrid(),
              ],
            ),
          ),

          const SizedBox(height: 16),

          // ── Booking list for selected day ─────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: Row(
              children: [
                Text(
                  _selectedDay != null
                      ? 'Booking ${_selectedDay!.day} ${_monthName(_selectedDay!.month)}'
                      : 'Semua Booking Mendatang',
                  style: const TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                      color: AppColors.black),
                ),
                if (_selectedDay != null) ...[
                  const Spacer(),
                  GestureDetector(
                    onTap: () => setState(() => _selectedDay = null),
                    child: const Text('Lihat Semua',
                        style:
                        TextStyle(fontSize: 12, color: AppColors.grey)),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(height: 10),

          Expanded(
            child: selectedBookings.isEmpty
                ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: const [
                  Icon(Icons.calendar_today_outlined,
                      size: 40, color: AppColors.grey),
                  SizedBox(height: 10),
                  Text('Tidak ada booking di hari ini',
                      style: TextStyle(
                          fontSize: 13, color: AppColors.grey)),
                ],
              ),
            )
                : ListView.builder(
              padding:
              const EdgeInsets.fromLTRB(20, 0, 20, 24),
              itemCount: selectedBookings.length,
              itemBuilder: (_, i) =>
                  _ScheduleCard(booking: selectedBookings[i]),
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => const BookingScreen())),
        backgroundColor: AppColors.primary,
        foregroundColor: AppColors.black,
        elevation: 0,
        icon: const Icon(Icons.add),
        label: const Text('Booking Baru',
            style: TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
  }

  Widget _buildDaysGrid() {
    final firstDay = DateTime(_focusedMonth.year, _focusedMonth.month, 1);
    final daysInMonth =
        DateTime(_focusedMonth.year, _focusedMonth.month + 1, 0).day;
    final startWeekday = firstDay.weekday % 7; // 0=Sun
    final today = DateTime.now();

    final cells = <Widget>[];
    for (int i = 0; i < startWeekday; i++) {
      cells.add(const SizedBox(width: 32, height: 32));
    }
    for (int d = 1; d <= daysInMonth; d++) {
      final date = DateTime(_focusedMonth.year, _focusedMonth.month, d);
      final isToday = _isSameDay(date, today);
      final isBooked = _isBooked(date);
      final isSelected =
          _selectedDay != null && _isSameDay(date, _selectedDay!);

      cells.add(GestureDetector(
        onTap: () => setState(() =>
        _selectedDay = isSelected ? null : date),
        child: Container(
          width: 32, height: 32,
          decoration: BoxDecoration(
            color: isSelected
                ? AppColors.black
                : isToday
                ? AppColors.primary
                : Colors.transparent,
            shape: BoxShape.circle,
          ),
          child: Stack(
            alignment: Alignment.center,
            children: [
              Text(
                '$d',
                style: TextStyle(
                  fontSize: 12,
                  fontWeight:
                  isToday || isSelected ? FontWeight.w700 : FontWeight.normal,
                  color: isSelected
                      ? Colors.white
                      : isToday
                      ? AppColors.black
                      : AppColors.black,
                ),
              ),
              if (isBooked && !isSelected)
                Positioned(
                  bottom: 3,
                  child: Container(
                    width: 4, height: 4,
                    decoration: const BoxDecoration(
                      color: AppColors.primary,
                      shape: BoxShape.circle,
                    ),
                  ),
                ),
            ],
          ),
        ),
      ));
    }

    final rows = <Widget>[];
    for (int i = 0; i < cells.length; i += 7) {
      final rowCells = cells.sublist(i, i + 7 > cells.length ? cells.length : i + 7);
      while (rowCells.length < 7) rowCells.add(const SizedBox(width: 32, height: 32));
      rows.add(Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: rowCells,
      ));
      if (i + 7 < cells.length) rows.add(const SizedBox(height: 4));
    }
    return Column(children: rows);
  }

  String _monthLabel(DateTime d) {
    const months = ['Januari','Februari','Maret','April','Mei','Juni',
      'Juli','Agustus','September','Oktober','November','Desember'];
    return '${months[d.month - 1]} ${d.year}';
  }

  String _monthName(int month) {
    const months = ['Jan','Feb','Mar','Apr','Mei','Jun',
      'Jul','Agu','Sep','Okt','Nov','Des'];
    return months[month - 1];
  }
}

class _ScheduleCard extends StatelessWidget {
  final Map<String, dynamic> booking;
  const _ScheduleCard({required this.booking});

  @override
  Widget build(BuildContext context) {
    final date = booking['date'] as DateTime;
    const months = ['Jan','Feb','Mar','Apr','Mei','Jun',
      'Jul','Agu','Sep','Okt','Nov','Des'];

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Row(
        children: [
          // Date box
          Container(
            width: 52, height: 58,
            decoration: BoxDecoration(
              color: AppColors.primary,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('${date.day}',
                    style: const TextStyle(
                        fontSize: 20,
                        fontWeight: FontWeight.w800,
                        color: AppColors.black,
                        height: 1.0)),
                Text(months[date.month - 1],
                    style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w600,
                        color: AppColors.black)),
              ],
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(booking['studio'] as String,
                    style: const TextStyle(
                        fontSize: 14,
                        fontWeight: FontWeight.w700,
                        color: AppColors.black)),
                const SizedBox(height: 3),
                Row(children: [
                  const Icon(Icons.access_time_outlined,
                      size: 12, color: AppColors.grey),
                  const SizedBox(width: 4),
                  Text(booking['time'] as String,
                      style: const TextStyle(
                          fontSize: 12, color: AppColors.grey)),
                ]),
                const SizedBox(height: 4),
                Container(
                  padding: const EdgeInsets.symmetric(
                      horizontal: 8, vertical: 3),
                  decoration: BoxDecoration(
                    color: AppColors.background,
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(booking['package'] as String,
                      style: const TextStyle(
                          fontSize: 10,
                          fontWeight: FontWeight.w600,
                          color: AppColors.grey)),
                ),
              ],
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(
                horizontal: 10, vertical: 4),
            decoration: BoxDecoration(
              color: const Color(0xFFFFF3DC),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Text('Akan Datang',
                style: TextStyle(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFFC08800))),
          ),
        ],
      ),
    );
  }
}