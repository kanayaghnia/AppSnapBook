import 'package:flutter/material.dart';
import 'package:snapbook/screens/auth/auth_screen.dart';

void main() {
  runApp(const SnapbookApp());
}

class SnapbookApp extends StatelessWidget {
  const SnapbookApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Snapbook',
      home: const AuthScreen(),
    );
  }
}